﻿CREATE TABLE [dbo].[Table1]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [EmployeeID] INT NOT NULL, 
    [EmployeeName] NVARCHAR(50) NOT NULL, 
    [RateOfPay] MONEY NOT NULL, 
    [HoursWorked] DECIMAL NOT NULL, 
    [PayWeek] DATE NOT NULL
)

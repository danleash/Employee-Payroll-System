﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using EmployeePayrollSystem.Models;

namespace EmployeePayrollSystem.Models
{
    public partial class EmployeePayrollDBContext : DbContext
    {
        public EmployeePayrollDBContext()
        {
        }

        public EmployeePayrollDBContext(DbContextOptions<EmployeePayrollDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Payroll> Table1 { get; set; }

//        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
//        {
//            if (!optionsBuilder.IsConfigured)
//            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
//                optionsBuilder.UseSqlServer("Server=(localdb)\\MSSQLLocalDB;Initial Catalog=EmployeePayrollDB;Integrated Security=True;Connect Timeout=60;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
//            }
//        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<Payroll>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.EmployeeID).HasColumnName("EmployeeID");

                entity.Property(e => e.EmployeeName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.HoursWorked).HasColumnType("decimal(18, 0)");

                entity.Property(e => e.PayWeek).HasColumnType("date");

                entity.Property(e => e.RateOfPay).HasColumnType("money");
            });
        }

       // public DbSet<EmployeePayrollSystem.Models.Payroll> Payroll { get; set; }
    }
}

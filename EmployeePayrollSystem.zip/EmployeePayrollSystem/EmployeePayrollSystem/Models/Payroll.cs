﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeePayrollSystem.Models
{
    public class Payroll
    {
        public int Id { get; set; }
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public double RateOfPay { get; set;}
        public double HoursWorked { get; set; }
        public DateTime PayWeek { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace EmployeePayrollSystem.Models
{
    public class EmployeeViewModel
    {
        public List<Payroll> Payrolls { get; set; }
        public SelectList PayWeek { get; set; }
        public string SearchString { get; set; }
        public DateTime PayWeekDate { get; set; }

    }
}